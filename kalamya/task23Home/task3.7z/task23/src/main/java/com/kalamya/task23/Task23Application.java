package com.kalamya.task23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task23Application {

	public static void main(String[] args) {
		SpringApplication.run(Task23Application.class, args);
	}

}
